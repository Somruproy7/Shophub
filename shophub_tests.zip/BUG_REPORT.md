# ShopHub - Defects found during test automation

Each defect has a matching `xfail(strict=True)` test. When a bug is fixed, its test starts passing,
strict mode flags it, and the `xfail` marker can be removed.

| ID | Severity | Area | Summary |
|----|----------|------|---------|
| BUG-001 | High | Security | `GET /order/<id>/` has no login or ownership check, so anyone can read any order (IDOR). |
| BUG-002 | Medium | Cart | Products with `available=False` can still be added to the cart. |
| BUG-003 | Medium | Cart | "Buy now" keeps existing cart items, so the buyer pays for items they did not choose. |
| BUG-004 | Low | API | `POST /cart/update/<id>/` with a non-numeric quantity returns HTTP 500 instead of 400. |

## BUG-001 - Any user can view any order
- **Steps:** create an order as user A; request `/order/<id>/` anonymously or as user B.
- **Expected:** 302 to login, or 403/404.
- **Actual:** 200 with the order details.
- **Cause:** `order_detail` is not decorated with `@login_required` and does not filter by `user`.
- **Fix:** add `@login_required` and `get_object_or_404(Order, pk=order_id, user=request.user)`.
- **Test:** `tests/test_security.py`

## BUG-002 - Unavailable product can be added to cart
- **Steps:** set `available=False` on a product; call `/cart/add/<id>/` while logged in.
- **Expected:** item is rejected.
- **Actual:** item is added to the cart.
- **Test:** `tests/test_cart_flow.py::test_unavailable_product_cannot_be_added_to_cart`

## BUG-003 - Buy now does not clear the cart
- **Steps:** add product A to the cart; click "Buy now" on product B.
- **Expected:** checkout contains only B.
- **Actual:** checkout contains A and B.
- **Cause:** `Cart.clear()` replaces `session['cart']` but `self.cart` still points to the old dict, so the next `add()` saves the old contents back.
- **Fix:** in `Cart.clear()`, also set `self.cart = {}`.
- **Test:** `tests/test_cart_flow.py::test_buy_now_replaces_cart_and_goes_to_checkout`

## BUG-004 - Non-numeric quantity causes a server error
- **Steps:** `POST /cart/update/<id>/` with `action=set&quantity=abc`.
- **Expected:** 400 with a validation message.
- **Actual:** 500 (`ValueError` caught by a generic handler).
- **Test:** `tests/test_cart_flow.py::test_update_non_numeric_quantity_does_not_crash_with_500`
