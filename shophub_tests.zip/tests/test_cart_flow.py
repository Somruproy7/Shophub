"""Cart views and the JSON quantity-update endpoint."""
import json

import pytest
from django.urls import reverse


def test_add_to_cart_stores_item_and_redirects(auth_client, product):
    resp = auth_client.get(reverse("store:add_to_cart", args=[product.id]))
    assert resp.status_code == 302
    assert auth_client.session["cart"][str(product.id)]["quantity"] == 1


def test_add_unknown_product_returns_404(auth_client, db):
    assert auth_client.get(reverse("store:add_to_cart", args=[99999])).status_code == 404


def test_cart_page_shows_total(auth_client, product, second_product):
    auth_client.get(reverse("store:add_to_cart", args=[product.id]))
    auth_client.get(reverse("store:add_to_cart", args=[second_product.id]))
    resp = auth_client.get(reverse("store:cart"))
    assert resp.status_code == 200
    assert resp.context["total"] == pytest.approx(2298.50)


def test_remove_from_cart(auth_client, product):
    auth_client.get(reverse("store:add_to_cart", args=[product.id]))
    auth_client.get(reverse("store:remove_from_cart", args=[product.id]))
    assert str(product.id) not in auth_client.session["cart"]


@pytest.mark.regression
@pytest.mark.xfail(strict=True, reason="BUG-003: buy_now keeps old cart items because Cart.clear() does not reset self.cart")
def test_buy_now_replaces_cart_and_goes_to_checkout(auth_client, product, second_product):
    auth_client.get(reverse("store:add_to_cart", args=[second_product.id]))
    resp = auth_client.get(reverse("store:buy_now", args=[product.id]))
    assert resp.url == reverse("store:checkout")
    assert list(auth_client.session["cart"]) == [str(product.id)]


def _update(client, product_id, **data):
    return client.post(reverse("store:update_cart_quantity", args=[product_id]), data)


def test_update_increment(auth_client, product):
    auth_client.get(reverse("store:add_to_cart", args=[product.id]))
    body = json.loads(_update(auth_client, product.id, action="inc").content)
    assert body["quantity"] == 2
    assert body["total"] == pytest.approx(3998.00)


def test_update_decrement_to_zero_removes_item(auth_client, product):
    auth_client.get(reverse("store:add_to_cart", args=[product.id]))
    body = json.loads(_update(auth_client, product.id, action="dec").content)
    assert body["quantity"] == 0


def test_update_set_quantity(auth_client, product):
    auth_client.get(reverse("store:add_to_cart", args=[product.id]))
    body = json.loads(_update(auth_client, product.id, action="set", quantity="7").content)
    assert body["quantity"] == 7


def test_update_invalid_action_returns_400(auth_client, product):
    assert _update(auth_client, product.id, action="explode").status_code == 400


@pytest.mark.regression
@pytest.mark.xfail(strict=True, reason="BUG-004: non-numeric quantity returns HTTP 500 instead of a 4xx validation error")
def test_update_non_numeric_quantity_does_not_crash_with_500(auth_client, product):
    auth_client.get(reverse("store:add_to_cart", args=[product.id]))
    resp = _update(auth_client, product.id, action="set", quantity="abc")
    assert resp.status_code in (400, 422), f"expected a client error, got {resp.status_code}"


@pytest.mark.regression
@pytest.mark.xfail(strict=True, reason="BUG-002: unavailable products can still be added to the cart")
def test_unavailable_product_cannot_be_added_to_cart(auth_client, product):
    product.available = False
    product.save()
    auth_client.get(reverse("store:add_to_cart", args=[product.id]))
    assert str(product.id) not in auth_client.session.get("cart", {})
