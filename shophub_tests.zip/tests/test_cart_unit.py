"""Unit tests for the session-backed Cart class."""
import pytest
from django.contrib.sessions.backends.db import SessionStore

from store.cart import Cart


class FakeRequest:
    def __init__(self):
        self.session = SessionStore()


@pytest.fixture
def cart(db):
    return Cart(FakeRequest())


def test_new_cart_is_empty(cart):
    assert list(cart.items()) == []
    assert cart.total() == 0


def test_add_item_sets_quantity_and_price(cart):
    cart.add(1, "100.00")
    assert cart.cart["1"] == {"quantity": 1, "price": "100.00"}


def test_adding_same_item_twice_increments_quantity(cart):
    cart.add(1, "100.00")
    cart.add(1, "100.00")
    assert cart.cart["1"]["quantity"] == 2


def test_total_sums_all_lines(cart):
    cart.add(1, "100.00", quantity=2)
    cart.add(2, "50.50")
    assert cart.total() == pytest.approx(250.50)


def test_remove_deletes_line(cart):
    cart.add(1, "100.00")
    cart.remove(1)
    assert "1" not in cart.cart


def test_remove_missing_item_is_a_noop(cart):
    cart.remove(999)
    assert cart.total() == 0


def test_set_quantity_updates_line(cart):
    cart.add(1, "10.00")
    cart.set_quantity(1, 5)
    assert cart.cart["1"]["quantity"] == 5


@pytest.mark.parametrize("qty", [0, -1, -50])
def test_set_quantity_zero_or_negative_removes_line(cart, qty):
    cart.add(1, "10.00")
    cart.set_quantity(1, qty)
    assert "1" not in cart.cart


def test_clear_empties_cart(cart):
    cart.add(1, "10.00")
    cart.add(2, "20.00")
    cart.clear()
    assert cart.session["cart"] == {}
