"""Checkout (COD), order creation, order editing and profile."""
from decimal import Decimal

import pytest
from django.urls import reverse

from store.models import Address, Order, OrderItem


def _checkout(client, address_data):
    return client.post(reverse("store:checkout"), address_data)


def test_checkout_with_empty_cart_redirects_home(auth_client):
    resp = auth_client.get(reverse("store:checkout"))
    assert resp.status_code == 302 and resp.url == reverse("store:home")


def test_checkout_creates_order_items_and_clears_cart(auth_client, product, second_product, address_data):
    auth_client.get(reverse("store:add_to_cart", args=[product.id]))
    auth_client.get(reverse("store:add_to_cart", args=[second_product.id]))
    resp = _checkout(auth_client, address_data)

    order = Order.objects.get()
    assert resp.url == reverse("store:order_detail", args=[order.id])
    assert order.total == Decimal("2298.50")
    assert order.payment_method == "cod" and order.paid is False
    assert OrderItem.objects.filter(order=order).count() == 2
    assert auth_client.session["cart"] == {}


def test_checkout_invalid_address_creates_no_order(auth_client, product, address_data):
    auth_client.get(reverse("store:add_to_cart", args=[product.id]))
    address_data["postal_code"] = ""
    resp = _checkout(auth_client, address_data)
    assert resp.status_code == 200
    assert Order.objects.count() == 0 and Address.objects.count() == 0


def test_order_item_price_is_snapshot_of_price_at_purchase(auth_client, product, address_data):
    auth_client.get(reverse("store:add_to_cart", args=[product.id]))
    _checkout(auth_client, address_data)
    product.price = Decimal("5.00")
    product.save()
    assert OrderItem.objects.get().price == Decimal("1999.00")


def test_order_edit_updates_address_for_unpaid_order(auth_client, user, product, address_data):
    auth_client.get(reverse("store:add_to_cart", args=[product.id]))
    _checkout(auth_client, address_data)
    order = Order.objects.get()
    auth_client.post(reverse("store:order_edit", args=[order.id]), {**address_data, "city": "Delhi"})
    order.address.refresh_from_db()
    assert order.address.city == "Delhi"


def test_paid_order_cannot_be_edited(auth_client, user, product, address_data):
    auth_client.get(reverse("store:add_to_cart", args=[product.id]))
    _checkout(auth_client, address_data)
    order = Order.objects.get()
    order.paid = True
    order.save()
    auth_client.post(reverse("store:order_edit", args=[order.id]), {**address_data, "city": "Delhi"})
    order.address.refresh_from_db()
    assert order.address.city == "Kolkata"


@pytest.mark.security
def test_user_cannot_edit_another_users_order(client, user, other_user, product, address_data):
    client.force_login(user)
    client.get(reverse("store:add_to_cart", args=[product.id]))
    _checkout(client, address_data)
    order = Order.objects.get()

    client.force_login(other_user)
    resp = client.post(reverse("store:order_edit", args=[order.id]), {**address_data, "city": "Hacked"})
    assert resp.status_code == 404


def test_profile_lists_only_own_orders(client, user, other_user, product, address_data):
    client.force_login(other_user)
    client.get(reverse("store:add_to_cart", args=[product.id]))
    _checkout(client, address_data)

    client.force_login(user)
    resp = client.get(reverse("store:profile"))
    assert list(resp.context["orders"]) == []
