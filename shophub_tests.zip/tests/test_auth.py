"""Registration, login, logout and login-required behaviour."""
import pytest
from django.contrib.auth.models import User
from django.urls import reverse

from store.models import Profile


@pytest.mark.smoke
@pytest.mark.parametrize("name", ["store:home", "store:login", "store:register"])
def test_public_pages_load(client, db, name):
    assert client.get(reverse(name)).status_code == 200


def test_register_creates_user_with_hashed_password_and_logs_in(client, db):
    resp = client.post(reverse("store:register"),
                       {"username": "newuser", "email": "n@example.com", "password": "Pass-12345"})
    assert resp.status_code == 302
    user = User.objects.get(username="newuser")
    assert user.password != "Pass-12345" and user.check_password("Pass-12345")
    assert client.session["_auth_user_id"] == str(user.pk)


def test_register_auto_creates_profile(client, db):
    client.post(reverse("store:register"),
                {"username": "newuser", "email": "n@example.com", "password": "Pass-12345"})
    assert Profile.objects.filter(user__username="newuser").exists()


def test_register_duplicate_username_is_rejected(client, user):
    resp = client.post(reverse("store:register"),
                       {"username": "alice", "email": "x@example.com", "password": "Pass-12345"})
    assert resp.status_code == 200
    assert User.objects.filter(username="alice").count() == 1


def test_register_missing_password_is_rejected(client, db):
    resp = client.post(reverse("store:register"), {"username": "nopass", "email": "n@example.com"})
    assert resp.status_code == 200
    assert not User.objects.filter(username="nopass").exists()


def test_login_with_valid_credentials(client, user):
    resp = client.post(reverse("store:login"), {"username": "alice", "password": "S3cure-pass!"})
    assert resp.status_code == 302
    assert "_auth_user_id" in client.session


def test_login_with_wrong_password_fails(client, user):
    resp = client.post(reverse("store:login"), {"username": "alice", "password": "wrong"})
    assert resp.status_code == 200
    assert "_auth_user_id" not in client.session


def test_logout_clears_session(auth_client):
    auth_client.get(reverse("store:logout"))
    assert "_auth_user_id" not in auth_client.session


@pytest.mark.security
@pytest.mark.parametrize("name,kwargs", [
    ("store:cart", {}), ("store:profile", {}), ("store:checkout", {}),
    ("store:add_to_cart", {"product_id": 1}), ("store:clear_cart", {}),
])
def test_protected_pages_redirect_anonymous_users_to_login(client, name, kwargs):
    resp = client.get(reverse(name, kwargs=kwargs))
    assert resp.status_code == 302
    assert resp.url.startswith("/login/")
