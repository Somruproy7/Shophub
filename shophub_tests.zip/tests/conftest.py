"""Shared fixtures. MongoDB is mocked so tests run without a database server."""
from decimal import Decimal

import pytest
from django.contrib.auth.models import User

from store.models import Category, Product


@pytest.fixture(autouse=True)
def mock_mongo(monkeypatch):
    """Stop every Mongo call from touching the network; keep tests fast and isolated."""
    from store import mongo

    for name in ("upsert_user", "remove_user", "upsert_product", "remove_product", "save_order"):
        monkeypatch.setattr(mongo, name, lambda *a, **k: None)
    monkeypatch.setattr(mongo, "get_products", lambda *a, **k: [])
    monkeypatch.setattr(mongo, "get_product_by_slug", lambda *a, **k: None)


@pytest.fixture
def category(db):
    return Category.objects.create(name="Audio", slug="audio")


@pytest.fixture
def product(db, category):
    return Product.objects.create(
        title="Wireless Headphones", slug="wireless-headphones",
        description="Over-ear", price=Decimal("1999.00"), category=category,
    )


@pytest.fixture
def second_product(db, category):
    return Product.objects.create(
        title="USB Cable", slug="usb-cable", price=Decimal("299.50"), category=category,
    )


@pytest.fixture
def user(db):
    return User.objects.create_user("alice", "alice@example.com", "S3cure-pass!")


@pytest.fixture
def other_user(db):
    return User.objects.create_user("bob", "bob@example.com", "S3cure-pass!")


@pytest.fixture
def auth_client(client, user):
    client.force_login(user)
    return client


@pytest.fixture
def address_data():
    return {
        "full_name": "Alice Doe", "line1": "12 Park Street", "line2": "",
        "city": "Kolkata", "state": "WB", "postal_code": "700016", "country": "India",
    }
