"""Access-control regression tests for defects found while testing ShopHub."""
from decimal import Decimal

import pytest
from django.urls import reverse

from store.models import Order


@pytest.fixture
def someone_elses_order(db, other_user, product):
    return Order.objects.create(user=other_user, total=Decimal("1999.00"))


@pytest.mark.security
@pytest.mark.regression
@pytest.mark.xfail(strict=True, reason="BUG-001: order_detail has no login or ownership check (IDOR)")
def test_anonymous_user_cannot_view_an_order(client, someone_elses_order):
    resp = client.get(reverse("store:order_detail", args=[someone_elses_order.id]))
    assert resp.status_code in (302, 403, 404)


@pytest.mark.security
@pytest.mark.regression
@pytest.mark.xfail(strict=True, reason="BUG-001: order_detail has no ownership check (IDOR)")
def test_logged_in_user_cannot_view_another_users_order(auth_client, someone_elses_order):
    resp = auth_client.get(reverse("store:order_detail", args=[someone_elses_order.id]))
    assert resp.status_code in (403, 404)
